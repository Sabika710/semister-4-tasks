from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

NASA_API_KEY = "DEMO_KEY"  # Replace with your own NASA API Key
NASA_APOD_URL = "https://api.nasa.gov/planetary/apod"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_apod")
def get_apod():
    """Fetch Astronomy Picture of the Day (APOD) from NASA API"""
    params = {"api_key": NASA_API_KEY}
    response = requests.get(NASA_APOD_URL, params=params)
    data = response.json()
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)
